package com.example.demo.entity;

import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="leave_table")
public class LeaveEntity {
	@Id
	@Column(name="emp_id")
	private int id;
	@Column(name="userid")
	private String empName;
	
	private String start_date;
	
	private String end_date;
	
	private int leave_days;
	
	private String leave_type;

	public LeaveEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public int hashCode() {
		return Objects.hash(empName, end_date, id, leave_days, leave_type, start_date);
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LeaveEntity other = (LeaveEntity) obj;
		return Objects.equals(empName, other.empName) && Objects.equals(end_date, other.end_date) && id == other.id
				&& leave_days == other.leave_days && Objects.equals(leave_type, other.leave_type)
				&& Objects.equals(start_date, other.start_date);
	}



	public int getLeave_days() {
		return leave_days;
	}






	public void setLeave_days(int leave_days) {
		this.leave_days = leave_days;
	}

	public String getLeave_type() {
		return leave_type;
	}


	public void setLeave_type(String leave_type) {
		this.leave_type = leave_type;
	}



	public LeaveEntity(int id, String empName, String start_date, String end_date, int leave_days, String leave_type) {
		super();
		this.id = id;
		this.empName = empName;
		this.start_date = start_date;
		this.end_date = end_date;
		this.leave_days = leave_days;
		this.leave_type = leave_type;
	}

	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}



	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}


	public String getStart_date() {
		return start_date;
	}





	public void setStart_date(String start_date) {
		this.start_date = start_date;
	}





	public String getEnd_date() {
		return end_date;
	}





	public void setEnd_date(String end_date) {
		this.end_date = end_date;
	}
















	@Override
	public String toString() {
		return "LeaveEntity [id=" + id + ", empName=" + empName + ", start_date=" + start_date + ", end_date="
				+ end_date + ", leave_days=" + leave_days + ", leave_type=" + leave_type + "]";
	}

	
}
