package com.example.demo.exceptions;
public class LeaveTypeException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public LeaveTypeException(String message) {
		super(message);
	}
}
