package com.example.demo.service;




import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.DAO.DataRepository;
import com.example.demo.entity.Data;








@Service
public class DataService {
	
	@Autowired
	private DataRepository dRepo;
	
	public Data updateInsurance(Integer id,byte[] insurance) {
		Data user = dRepo.findById(id).orElseThrow();
		//user.setFilename(fileName);
		user.setInsurance(insurance);
		return dRepo.save(user);
	}
	
	public Data updateBankAccount(Integer id,byte[] bankaccount) {
		Data user = dRepo.findById(id).orElseThrow();
		//user.setFilename(fileName);
		user.setBankaccount(bankaccount);
		return dRepo.save(user);
	}
	
	public Data getData(int empid) {
		Optional<Data> pdata=Optional.ofNullable(dRepo.findByEmpid(empid));
		if(pdata.isPresent()) {
			return pdata.get();
		}
		throw new RuntimeException(empid+" Profile is not exist ");
	}	
}