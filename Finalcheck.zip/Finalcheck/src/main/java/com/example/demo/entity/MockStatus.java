package com.example.demo.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="employee_status")
public class MockStatus {
	@Id
	private int empid;
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	@Column
	private String userid;
	@Column(name="task_1")
	private boolean task_1;
	@Column(name="task_2")
	private boolean task_2 ;
	@Column(name="task_3")
	private boolean task_3;
	@Column(name="task_4")
	private boolean task_4;
	@Column(name="task_5")
	private boolean task_5;
	@Column(name="task_6")
	private boolean task_6;
	@Column(name="task_7")
	private boolean task_7;
	@Column(name="task_8")
	private boolean task_8;
	@Column(name="task_9")
	private boolean task_9;
	@Column(name="task_10")
	private boolean task_10;
	public MockStatus() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public boolean isTask_1() {
		return task_1;
	}
	public void setTask_1(boolean task_1) {
		this.task_1 = task_1;
	}
	public boolean isTask_2() {
		return task_2;
	}
	public void setTask_2(boolean task_2) {
		this.task_2 = task_2;
	}
	public boolean isTask_3() {
		return task_3;
	}
	public void setTask_3(boolean task_3) {
		this.task_3 = task_3;
	}
	public boolean isTask_4() {
		return task_4;
	}
	public void setTask_4(boolean task_4) {
		this.task_4 = task_4;
	}
	public boolean isTask_5() {
		return task_5;
	}
	public void setTask_5(boolean task_5) {
		this.task_5 = task_5;
	}
	public boolean isTask_6() {
		return task_6;
	}
	public void setTask_6(boolean task_6) {
		this.task_6 = task_6;
	}
	public boolean isTask_7() {
		return task_7;
	}
	public void setTask_7(boolean task_7) {
		this.task_7 = task_7;
	}
	public boolean isTask_8() {
		return task_8;
	}
	public void setTask_8(boolean task_8) {
		this.task_8 = task_8;
	}
	public boolean isTask_9() {
		return task_9;
	}
	public void setTask_9(boolean task_9) {
		this.task_9 = task_9;
	}
	public boolean isTask_10() {
		return task_10;
	}
	public void setTask_10(boolean task_10) {
		this.task_10 = task_10;
	}
	@Override
	public String toString() {
		return "MockStatus [empid=" + empid + ", userid=" + userid + ", task_1=" + task_1 + ", task_2=" + task_2
				+ ", task_3=" + task_3 + ", task_4=" + task_4 + ", task_5=" + task_5 + ", task_6=" + task_6
				+ ", task_7=" + task_7 + ", task_8=" + task_8 + ", task_9=" + task_9 + ", task_10=" + task_10 + "]";
	}
	public MockStatus(int empid, String userid, boolean task_1, boolean task_2, boolean task_3, boolean task_4,
			boolean task_5, boolean task_6, boolean task_7, boolean task_8, boolean task_9, boolean task_10) {
		super();
		this.empid = empid;
		this.userid = userid;
		this.task_1 = task_1;
		this.task_2 = task_2;
		this.task_3 = task_3;
		this.task_4 = task_4;
		this.task_5 = task_5;
		this.task_6 = task_6;
		this.task_7 = task_7;
		this.task_8 = task_8;
		this.task_9 = task_9;
		this.task_10 = task_10;
	}
	
	

}