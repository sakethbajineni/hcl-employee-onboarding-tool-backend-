package com.example.demo.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name ="mock_data")
public class LoginDetails {
	@Id
	@JsonIgnore
	@Column
	private int employeeid;

	
	@Column

	private String userid;
	@Column(name = "pass_word")
	private String password;

	@Override
	public String toString() {
		return "LoginDetails [employeeid=" + employeeid + ", userid=" + userid + ", password=" + password + "]";
	}

	public int getEmployeeid() {
		return employeeid;
	}

	public void setEmployeeid(int employeeid) {
		this.employeeid = employeeid;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}[]
