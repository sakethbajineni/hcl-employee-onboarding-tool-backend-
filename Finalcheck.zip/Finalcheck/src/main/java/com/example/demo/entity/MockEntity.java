package com.example.demo.entity;

import java.sql.Date;
import java.util.Arrays;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;

@Entity
@Table(name="mock_data")
public class MockEntity {
	@Id
	@Column
	private int employeeid;
	@Column
	private String Fullname;
	@Column
	private String designation;
	@Column
	private String joining_location;
	@Column
	private Date joining_date;
	@Column
	private int tower;
	@Column
	private String odc;
	@Lob
	private byte[] photo;
	
	
	
	public byte[] getPhoto() {
		return photo;
	}
	public void setPhoto(byte[] photo) {
		this.photo = photo;
	}
	@Column
	
	private String userid;
	@JsonIgnore
	@Column(name="pass_word")
	private String password;
	
	
	
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getFullname() {
		return Fullname;
	}
	public void setFullname(String fullname) {
		Fullname = fullname;
	}
	
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getJoining_location() {
		return joining_location;
	}
	public void setJoining_location(String joining_location) {
		this.joining_location = joining_location;
	}
	public Date getJoining_date() {
		return joining_date;
	}
	public void setJoining_date(Date joining_date) {
		this.joining_date = joining_date;
	}
	public int getTower() {
		return tower;
	}
	public void setTower(int tower) {
		this.tower = tower;
	}
	public String getOdc() {
		return odc;
	}
	public void setOdc(String odc) {
		this.odc = odc;
	}
	
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	
	
	@Override
	public String toString() {
		return "MockEntity [employeeid=" + employeeid + ", Fullname=" + Fullname + ", designation=" + designation
				+ ", joining_location=" + joining_location + ", joining_date=" + joining_date + ", tower=" + tower
				+ ", odc=" + odc + ", photo=" + Arrays.toString(photo) + ", userid=" + userid + ", password=" + password
				+ "]";
	}
	public int getEmployeeid() {
		return employeeid;
	}
	public void setEmployeeid(int employeeid) {
		this.employeeid = employeeid;
	}
	
	

}
