package com.example.demo.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entity.LeaveBalance;



public interface LeavebalanceRepo extends JpaRepository<LeaveBalance,Integer>{

}
