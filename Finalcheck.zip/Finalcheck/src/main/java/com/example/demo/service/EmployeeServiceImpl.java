package com.example.demo.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.demo.DAO.EmployeeRepo;
import com.example.demo.DAO.LeavebalanceRepo;
import com.example.demo.entity.LeaveBalance;
import com.example.demo.entity.LeaveEntity;
import com.example.demo.exceptions.IdNotFoundException;
import com.example.demo.util.Utility;



@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepo repo;

	@Autowired
	private LeavebalanceRepo balRepo;

	@Autowired
	private Utility util;

	@Override
	public ResponseEntity<?> applyLeave(LeaveEntity entity) {

		String message = null;
		LeaveEntity res = new LeaveEntity();
		LeaveBalance balance = new LeaveBalance();

		Optional<LeaveBalance> balObject = balRepo.findById(entity.getId());
		if (balObject != null) {
			balance = balObject.get(); // Current Leave Balance
			if(!balance.getEmp_name().equalsIgnoreCase(entity.getEmpName())) {
				message="ERROR: "+entity.getEmpName()+" is Not a Valid Name";
				return ResponseEntity.ok(message);
			}
			try {
				balance = util.performBalanceCalculation(balance, entity);
				entity.setLeave_days(util.getNumOfDays(entity));;
				res = repo.save(entity);
			} 
			catch (Exception e) {
				e.getMessage();
				return ResponseEntity.ok(e.getMessage());
			}
			balRepo.save(balance);
			message = "SUCCESS: "+entity.getLeave_days()+"Leaves Applied for " + entity.getLeave_days() + " days";
			return ResponseEntity.ok(message);
		} 
		else {			
			message = "ERROR: Leave Application Not Completed";
			return ResponseEntity.ok(message);
		}
	}

	@Override
	public ResponseEntity<?> getLeaveBalance(int id) throws IdNotFoundException {
		LeaveBalance balance = null;
		try {
			Optional<LeaveBalance> res = balRepo.findById(id);
			if (res != null) {
				balance = res.get();
			}		
		} catch (Exception e) {			
			e.getMessage();
			return ResponseEntity.ok(e.getMessage());
		}
		return ResponseEntity.ok(balance);
	}

}
