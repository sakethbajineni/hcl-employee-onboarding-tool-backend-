package com.example.demo.entity;
import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;




@Entity
@Table(name="mock_data")
public class Data implements Serializable {

	private static final long serialVersionUID = 2842598520185366295L;
	@Id
	@Column (name="employeeid")
	private Integer empid;
	@Column (name="Fullname")
	private String name;
	private String surname;
	@Column (name="place_of_birth")
	private String placeOfBirth;
	@Column (name="full_address")
	private String fullAddress;
	@Column (name="contact_number")
	private Long contactnumber;
	private Integer zipcode;
	@Lob
	private byte[] photo;
	@Lob
	private byte[] idProof;
	@Lob
	private byte[] bankaccount;
	@Lob
	private byte[] insurance;
	
	public Data() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Data(int empid, String name, String surname, String placeOfBirth,
			String fullAddress, Long contactnumber, Integer zipcode, byte[] photo, byte[] idProof, byte[] bankaccount,
			byte[] insurance) {
		super();
		
		this.empid = empid;
		this.name = name;
		this.surname = surname;
		this.placeOfBirth = placeOfBirth;
		this.fullAddress = fullAddress;
		this.contactnumber = contactnumber;
		this.zipcode = zipcode;
		this.photo = photo;
		this.idProof = idProof;
		this.bankaccount = bankaccount;
		this.insurance = insurance;
	}

	

	public int getEmpid() {
		return empid;
	}

	public void setEmpId(int empid) {
		this.empid = empid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getPlaceOfBirth() {
		return placeOfBirth;
	}

	public void setPlaceOfBirth(String placeOfBirth) {
		this.placeOfBirth = placeOfBirth;
	}

	public String getFullAddress() {
		return fullAddress;
	}

	public void setFullAddress(String fullAddress) {
		this.fullAddress = fullAddress;
	}

	public Long getContactnumber() {
		return contactnumber;
	}

	public void setContactnumber(Long contactnumber) {
		this.contactnumber = contactnumber;
	}

	public Integer getZipcode() {
		return zipcode;
	}

	public void setZipcode(Integer zipcode) {
		this.zipcode = zipcode;
	}

	public byte[] getPhoto() {
		return photo;
	}

	public void setPhoto(byte[] photo) {
		this.photo = photo;
	}

	public byte[] getIdProof() {
		return idProof;
	}

	public void setIdProof(byte[] idProof) {
		this.idProof = idProof;
	}

	public byte[] getBankaccount() {
		return bankaccount;
	}

	public void setBankaccount(byte[] bankaccount) {
		this.bankaccount = bankaccount;
	}

	public byte[] getInsurance() {
		return insurance;
	}

	public void setInsurance(byte[] insurance) {
		this.insurance = insurance;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}