package com.example.demo.entity;

import java.sql.Date;

public class NewJoiners {
private String fullname;
private String designation;
private Date joining_date;
public NewJoiners(String fullname, String designation, Date joining_date) {
	super();
	this.fullname = fullname;
	this.designation = designation;
	this.joining_date = joining_date;
}
public String getFullname() {
	return fullname;
}
@Override
public String toString() {
	return "NewJoiners [fullname=" + fullname + ", designation=" + designation + ", joining_date=" + joining_date + "]";
}
public NewJoiners() {
	super();
	// TODO Auto-generated constructor stub
}
public void setFullname(String fullname) {
	this.fullname = fullname;
}
public String getDesignation() {
	return designation;
}
public void setDesignation(String designation) {
	this.designation = designation;
}
public Date getJoining_date() {
	return joining_date;
}
public void setJoining_date(Date joining_date) {
	this.joining_date = joining_date;
}
}