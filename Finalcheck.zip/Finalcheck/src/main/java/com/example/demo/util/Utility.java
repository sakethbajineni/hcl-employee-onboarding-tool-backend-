package com.example.demo.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.springframework.stereotype.Service;

import com.example.demo.entity.LeaveBalance;
import com.example.demo.entity.LeaveEntity;
import com.example.demo.exceptions.BalanceException;
import com.example.demo.exceptions.DATEException;
import com.example.demo.exceptions.DateParseException;
import com.example.demo.exceptions.LeaveTypeException;



@Service
public class Utility {

	public LeaveBalance performBalanceCalculation(LeaveBalance balance, LeaveEntity entity) throws Exception {
		LeaveBalance updtBalance = new LeaveBalance();
		int NumOfDays = 0;
		int remaining = 0;
		switch (entity.getLeave_type()) {

		case "Casual":
			NumOfDays = this.getNumOfDays(entity);
			remaining = balance.getCasual() - NumOfDays;
			if (remaining >= 0) {				
				updtBalance = balance;
				updtBalance.setCasual(remaining);
			} else {
				throw new BalanceException(
						"ERROR: NOT ENOUGH LEAVES AVAILABLE TO APPLY LEAVES FOR " + NumOfDays + " DAYS");
			}
			break;
		case "Anual":
			NumOfDays = this.getNumOfDays(entity);
			remaining = balance.getAnnual() - NumOfDays;
			if (remaining >= 0) {				
				updtBalance = balance;
				updtBalance.setAnnual(remaining);
			} else {
				throw new BalanceException(
						"ERROR: NOT ENOUGH LEAVES AVAILABLE TO APPLY LEAVES FOR " + NumOfDays + " DAYS");
			}
			break;
		case "Maternity":
			NumOfDays = this.getNumOfDays(entity);
			remaining = balance.getMaternity() - NumOfDays;
			if (remaining >= 0) {
				updtBalance = balance;
				updtBalance.setMaternity(remaining);
			} else {
				throw new BalanceException(
						"ERROR: NOT ENOUGH LEAVES AVAILABLE TO APPLY LEAVES FOR " + NumOfDays + " DAYS");
			}
			break;
		case "Paternity":
			NumOfDays = this.getNumOfDays(entity);
			remaining = balance.getPaternity() - NumOfDays;
			if (remaining >= 0) {
				updtBalance = balance;
				updtBalance.setPaternity(remaining);
			} else {
				throw new BalanceException(
						"ERROR: NOT ENOUGH LEAVES AVAILABLE TO APPLY LEAVES FOR " + NumOfDays + " DAYS");
			}
			break;
		case "Matrimony":
			NumOfDays = this.getNumOfDays(entity);
			remaining = balance.getMatrimony() - NumOfDays;
			if (remaining >= 0) {
				updtBalance = balance;
				updtBalance.setMatrimony(remaining);
			} else {
				throw new BalanceException(
						"ERROR: NOT ENOUGH LEAVES AVAILABLE TO APPLY LEAVES FOR " + NumOfDays + " DAYS");
			}
			break;
		case "Bereavement":
			NumOfDays = this.getNumOfDays(entity);
			remaining = balance.getMatrimony() - NumOfDays;
			if (remaining >= 0) {
				updtBalance = balance;
				updtBalance.setMatrimony(remaining);
			} else {
				throw new BalanceException(
						"ERROR: NOT ENOUGH LEAVES AVAILABLE TO APPLY LEAVES FOR " + NumOfDays + " DAYS");
			}
			break;
		
		default:
			throw new LeaveTypeException("ERROR: Requested " + entity.getLeave_type() + " is Not a Valid Leave Type");
			
		}
		return updtBalance;
	}

	public int getNumOfDays(LeaveEntity entity) throws Exception {
		int NumOfDays = 0;
		String sDateString = entity.getStart_date();
		String eDateString = entity.getEnd_date();
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd");
		Date sDate = null;
		Date eDate = null;
		try {
			sDate = df.parse(sDateString);
			eDate = df1.parse(eDateString);
		} catch (Exception ex) {
			throw new DateParseException("ERROR: Please Enter Date in yyyy-MM-dd Format");			
		}
		if (eDate.before(sDate)) {
			throw new DATEException("ERROR: End Date Should be Greater than Start Date");
		}
		long diffInMillis = eDate.getTime() - sDate.getTime();
		int DaysDiff = (int) TimeUnit.DAYS.convert(diffInMillis, TimeUnit.MILLISECONDS);
		NumOfDays = DaysDiff + 1;
		return NumOfDays;
	}	

}

