package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.LeaveEntity;
import com.example.demo.exceptions.IdNotFoundException;
import com.example.demo.service.EmployeeService;
import com.example.demo.service.EmployeeServiceImpl;



@RestController
@CrossOrigin
public class EmployeeController {
	
	@Autowired
	EmployeeServiceImpl serv;
	
	
	@PostMapping("/applyLeave")
	public ResponseEntity<?> applyLeave(@RequestBody LeaveEntity entity) {
		
		return serv.applyLeave(entity);				
	}
	@GetMapping("/leaveBalance")
	public ResponseEntity<?> getLeaveBalance(@RequestParam int id) throws IdNotFoundException {	
		
		return serv.getLeaveBalance(id);
		
	}
	
	
	
	

}
