package com.example.demo.service;
import org.springframework.http.ResponseEntity;

import com.example.demo.entity.LeaveEntity;
import com.example.demo.exceptions.IdNotFoundException;



public interface EmployeeService {

	ResponseEntity<?> applyLeave(LeaveEntity entity);

	ResponseEntity<?> getLeaveBalance(int id) throws IdNotFoundException;


}