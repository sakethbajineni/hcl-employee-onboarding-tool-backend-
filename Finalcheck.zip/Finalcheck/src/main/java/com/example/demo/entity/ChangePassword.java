package com.example.demo.entity;

public class ChangePassword {
	private String userid;
	private String password;
	private String newpassword;
	public ChangePassword(String userid, String password, String newpassword) {
		super();
		this.userid = userid;
		this.password = password;
		this.newpassword = newpassword;
	}
	public ChangePassword() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "ChangePassword [userid=" + userid + ", password=" + password + ", newpassword=" + newpassword + "]";
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getNewpassword() {
		return newpassword;
	}
	public void setNewpassword(String newpassword) {
		this.newpassword = newpassword;
	}
	

}
