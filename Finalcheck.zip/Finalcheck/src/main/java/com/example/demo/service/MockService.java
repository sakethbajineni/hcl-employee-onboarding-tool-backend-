package com.example.demo.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.demo.DAO.LoginDAO;
import com.example.demo.DAO.MockDAO;
import com.example.demo.DAO.MockStatusDAO;
import com.example.demo.entity.ChangePassword;
import com.example.demo.entity.LoginDetails;
import com.example.demo.entity.MockEntity;
import com.example.demo.entity.MockStatus;
import com.example.demo.entity.NewJoiners;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class MockService {
	@Autowired
	private MockDAO mock;
	@Autowired
	private LoginDAO ldao;
	@Autowired
	private MockStatusDAO mockdao;

	// LOGIN PAGE

		public  ResponseEntity<?> login(LoginDetails logindet) throws JsonProcessingException {
			if (!logindet.getUserid().isEmpty()) {
				LoginDetails login = new LoginDetails();
				login = ldao.findByUserid(logindet.getUserid());
				BCryptPasswordEncoder bcrypt = new BCryptPasswordEncoder();
				if(ldao.existsByUserid(logindet.getUserid())) {
				if (bcrypt.matches(logindet.getPassword(), login.getPassword())) {
					return ResponseEntity.ok("1");
				} else if (logindet.getPassword().isEmpty()) {
					Map<String,Object> errorMap=new HashMap<>();
					errorMap.put("status","error");
					errorMap.put("message","Password is required");
					ObjectMapper objmap=new ObjectMapper();
					String json=objmap.writeValueAsString(errorMap);
					return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(json);
					
				}

				else {
					Map<String,Object> errorMap=new HashMap<>();
					errorMap.put("status","error");
					errorMap.put("message","Incorrect Password");
					ObjectMapper objmap=new ObjectMapper();
					String json=objmap.writeValueAsString(errorMap);
					return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(json);
				}

			} else {
				Map<String,Object> errorMap=new HashMap<>();
				errorMap.put("status","error");
				errorMap.put("message","incorrect userid");
				ObjectMapper objmap=new ObjectMapper();
				String json=objmap.writeValueAsString(errorMap);
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(json);
			}
				}
					else {
						Map<String,Object> errorMap=new HashMap<>();
						errorMap.put("status","error");
						errorMap.put("message","Userid is required");
						ObjectMapper objmap=new ObjectMapper();
						String json=objmap.writeValueAsString(errorMap);
						return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(json);

			}}

	// CHANGE PASSWORD
	public String changePassword(ChangePassword chanpass) {
		String Regex = "(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,16}";
		System.out.println(chanpass.getPassword() + "" + chanpass.getNewpassword());
		LoginDetails logdetails = new LoginDetails();
		logdetails = ldao.findByUserid(chanpass.getUserid());
		if (logdetails.getPassword().equals(chanpass.getPassword())) {

			if (!(chanpass.getNewpassword().isBlank())) {

				System.out.println(chanpass.getNewpassword());
				if (chanpass.getNewpassword().matches(Regex)) {
					BCryptPasswordEncoder bcrypt=new BCryptPasswordEncoder();
					System.out.println(bcrypt.encode(chanpass.getNewpassword()));
					logdetails.setPassword(bcrypt.encode(chanpass.getNewpassword()));
					ldao.save(logdetails);
					return "Password Changed Successfully";
				} else {
					return "the new password is not qualified";
				}

			} else {
				return "NewPassword is blank ";
			}
		} else {
			return "incorrect data";

		}
	}

	// GET PROFILE
	public MockEntity getDatabyuserid(String userid) {

		Optional<MockEntity> dt = Optional.ofNullable(mock.findByUserid(userid));
		if (dt.isPresent()) {
			return dt.get();
		}

		throw new RuntimeException("The user data is not found");

	}

	// Get new joiners
	public List<NewJoiners> getAllData(String userid) {

		List<MockEntity> newlist = new ArrayList<MockEntity>();
		List<NewJoiners> newlist1 = new ArrayList<NewJoiners>();
		MockEntity MockEnt = new MockEntity();
		newlist.addAll(mock.findAll());
		for (int i = 0; i < newlist.size(); i++) {
			MockEnt = newlist.get(i);
			NewJoiners newjoin = new NewJoiners();

			if (!(userid.equals(MockEnt.getUserid()))) {
				System.out.println(MockEnt.getUserid());
				newjoin.setFullname(MockEnt.getFullname());
				newjoin.setDesignation(MockEnt.getDesignation());
				newjoin.setJoining_date(MockEnt.getJoining_date());
				newlist1.add(newjoin);

			}

		}
		return newlist1;
	}

	// GET STATUS
	public MockStatus getStatus(String userid) {
		List<MockStatus> list1 = new ArrayList<MockStatus>();
		MockStatus mockstat = new MockStatus();
		list1.addAll(mockdao.findAll());
		for (int j = 0; j < list1.size(); j++) {
			mockstat = list1.get(j);

			if ((userid.equals(mockstat.getUserid()))) {
				MockStatus mockstat1 = new MockStatus();
				mockstat1 = mockdao.findByUserid(userid);
				return mockstat1;
			}

		}
		throw new RuntimeException("Something went wrong userid is not correct");
	}

}
