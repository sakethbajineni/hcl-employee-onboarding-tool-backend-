package com.example.demo.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entity.LoginDetails;



public interface LoginDAO extends JpaRepository<LoginDetails,Integer> {
	Boolean existsByUserid(String userid);
	Boolean existsByPassword(String password);
	LoginDetails findByUserid(String userid);
	LoginDetails findByPassword(String password);

}