package com.example.demo.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.DAO.LoginDAO;
import com.example.demo.DAO.MockDAO;
import com.example.demo.DAO.MockStatusDAO;
import com.example.demo.entity.ChangePassword;
import com.example.demo.entity.LoginDetails;
import com.example.demo.entity.MockEntity;
import com.example.demo.entity.MockStatus;
import com.example.demo.entity.NewJoiners;
import com.example.demo.service.MockService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;






@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class LoginAndProfilerController {
	@Autowired
	private MockService mservice;
	@Autowired
	private MockDAO mock;
	@Autowired
	private MockStatusDAO mockdao;
	@Autowired
	private LoginDAO logg;

	@PostMapping("/loginpage")
	public ResponseEntity<?> getlogin(@RequestBody LoginDetails logdata) throws JsonProcessingException  {
		try {
		return mservice.login(logdata);
	}
		catch(Exception e) {
			Map<String,Object> errorMap=new HashMap<>();
			errorMap.put("status","error");
			errorMap.put("message", e.getMessage());
			ObjectMapper objmap=new ObjectMapper();
			String json=objmap.writeValueAsString(errorMap);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(json);
			
		}
	}

	/*
	 * @PutMapping("/changepassword") public ResponseEntity<String>
	 * Changepassword(@RequestParam String password, String newPassword,
	 * 
	 * @RequestBody(required = false) LoginDetails logdata) {
	 * 
	 * String Regex =
	 * "(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,16}";
	 * System.out.println(password + "" + newPassword); if
	 * (logg.existsByPassword(password)) { LoginDetails logindet =
	 * logg.findByPassword(password); if (!(newPassword.isBlank())) {
	 * 
	 * System.out.println(newPassword); if (newPassword.matches(Regex)) {
	 * logindet.setPassword(newPassword); logg.save(logindet); return new
	 * ResponseEntity<String>("Data saved successfully", HttpStatus.OK); } else {
	 * return new ResponseEntity<String>("the new password is not qualified",
	 * HttpStatus.OK); }
	 * 
	 * } else { return new ResponseEntity<String>("newPassword is blank ",
	 * HttpStatus.OK); } } return new ResponseEntity<String>("incorrect data",
	 * HttpStatus.OK);
	 * 
	 * }
	 */

	@GetMapping("/profile")
	public ResponseEntity<MockEntity> getdata(@RequestParam String userid) {

		

		return new ResponseEntity<MockEntity>(mservice.getDatabyuserid(userid), HttpStatus.OK);

	}

	@GetMapping("/newjoiners")
	public ResponseEntity<List<NewJoiners>> getAlltheData(@RequestParam String userid) {
		
		return new ResponseEntity<List<NewJoiners>>(mservice.getAllData(userid), HttpStatus.OK);

	}

	@GetMapping("/status")
	public ResponseEntity<MockStatus> getstatus(@RequestParam String userid) {
		return new ResponseEntity<MockStatus>(mservice.getStatus(userid), HttpStatus.OK);
	}
	

	
	@PutMapping("/changepasswords")
	public ResponseEntity<String> Changepassword(@RequestBody ChangePassword chanpass) {

		return new ResponseEntity<String>(mservice.changePassword(chanpass),HttpStatus.CREATED);
}
}
