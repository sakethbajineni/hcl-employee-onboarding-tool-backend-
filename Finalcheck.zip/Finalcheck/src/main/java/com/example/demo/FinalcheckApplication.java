package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinalcheckApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinalcheckApplication.class, args);
	}

}
