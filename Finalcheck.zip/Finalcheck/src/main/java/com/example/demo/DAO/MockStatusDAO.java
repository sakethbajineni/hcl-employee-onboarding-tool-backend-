package com.example.demo.DAO;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.MockStatus;



@Repository
public interface MockStatusDAO extends JpaRepository<MockStatus,String> {
	MockStatus findByUserid(String userid);

}
