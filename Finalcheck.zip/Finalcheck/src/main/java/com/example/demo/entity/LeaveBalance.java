package com.example.demo.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "leave_balance")
public class LeaveBalance {
	@Id
	@Column(name = "emp_id")
	public int id;
	@Column(name = "userid")
	public String emp_name;
	public int casual;
	public int annual;
	public int maternity;
	public int paternity;
	public int matrimony;
	public int bereavement;

	public LeaveBalance() {
		super();
		// TODO Auto-generated constructor stub
	}



	public LeaveBalance(int id, String emp_name, int casual, int annual, int maternity, int paternity, int matrimony,
			int bereavement) {
		super();
		this.id = id;
		this.emp_name = emp_name;
		this.casual = casual;
		this.annual = annual;
		this.maternity = maternity;
		this.paternity = paternity;
		this.matrimony = matrimony;
		this.bereavement = bereavement;
	}



	@Override
	public String toString() {
		return "LeaveBalance [id=" + id + ", emp_name=" + emp_name + ", casual=" + casual + ", annual=" + annual
				+ ", maternity=" + maternity + ", paternity=" + paternity + ", matrimony=" + matrimony
				+ ", bereavement=" + bereavement + "]";
	}



	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public String getEmp_name() {
		return emp_name;
	}

	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}

	public int getCasual() {
		return casual;
	}

	public void setCasual(int casual) {
		this.casual = casual;
	}

	public int getAnnual() {
		return annual;
	}

	public void setAnnual(int annual) {
		this.annual = annual;
	}

	public int getMaternity() {
		return maternity;
	}

	public void setMaternity(int maternity) {
		this.maternity = maternity;
	}

	public int getPaternity() {
		return paternity;
	}

	public void setPaternity(int paternity) {
		this.paternity = paternity;
	}

	public int getMatrimony() {
		return matrimony;
	}

	public void setMatrimony(int matrimony) {
		this.matrimony = matrimony;
	}

	public int getBereavement() {
		return bereavement;
	}

	public void setBereavement(int bereavement) {
		this.bereavement = bereavement;
	}

}
