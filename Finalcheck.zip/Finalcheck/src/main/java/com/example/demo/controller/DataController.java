package com.example.demo.controller;


import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.DAO.DataRepository;
import com.example.demo.entity.Data;
import com.example.demo.service.DataService;



@RestController

@RequestMapping("/upload/file")
public class DataController {

	@Autowired
	private DataRepository dRepo;
	
	@Autowired
	private DataService dService;

	@PostMapping(value = "/database")

	public String uploadToDatabase(@RequestParam String name, String surname,String fullAddress, String placeOfBirth,Long contactnumber,Integer zipcode, @RequestParam MultipartFile photo,MultipartFile idproof)
			throws IOException {

		// Set the form data into entity
		Data data = new Data();
		data.setName(name);
		data.setSurname(surname);
		data.setContactnumber(contactnumber);
		data.setFullAddress(fullAddress);
		data.setPlaceOfBirth(placeOfBirth);
		data.setZipcode(zipcode);
		data.setPhoto(photo.getBytes());
		data.setIdProof(idproof.getBytes());

		// Save the records into the database
		dRepo.save(data);

		return "Records saved into database.";
	}
	@PutMapping("/updateBankAccount/{id}")
	public Data updateBankAccount(@PathVariable Integer id,@RequestParam("bankaccount") MultipartFile multipartFile) {
		//String fileName = multipartFile.getOriginalFilename();
		byte[] bankAccount = null;
		try {
			bankAccount = multipartFile.getBytes();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return dService.updateBankAccount(id,bankAccount);
	}
	
	@PutMapping("/updateInsurance/{id}")
	public Data updateInsurance(@PathVariable Integer id,@RequestParam("insurance") MultipartFile multipartFile) {
		//String fileName = multipartFile.getOriginalFilename();
		byte[] insurance = null;
		try {
			insurance = multipartFile.getBytes();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return dService.updateInsurance(id,insurance);
	}
	
	@GetMapping("/GetData/{empId}")
	public ResponseEntity<Data> getSingleEmployee(@PathVariable int empId) {
		return new ResponseEntity<>(dService.getData(empId),HttpStatus.OK);
	}
	
}